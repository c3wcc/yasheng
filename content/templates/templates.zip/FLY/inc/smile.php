<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<a href="javascript:grin('[F1]')"  title="囧" ><img src="<?php echo TEMPLATE_URL; ?>img/face/1.gif" alt="囧"/></a>
<a href="javascript:grin('[F2]')"  title="亲" ><img src="<?php echo TEMPLATE_URL; ?>img/face/2.gif" alt="亲"/></a>
<a href="javascript:grin('[F3]')"  title="晕" ><img src="<?php echo TEMPLATE_URL; ?>img/face/3.gif" alt="晕"/></a>
<a href="javascript:grin('[F4]')"  title="酷" ><img src="<?php echo TEMPLATE_URL; ?>img/face/4.gif" alt="酷"/></a>
<a href="javascript:grin('[F5]')"  title="哭" ><img src="<?php echo TEMPLATE_URL; ?>img/face/5.gif" alt="哭" /></a>
<a href="javascript:grin('[F6]')"  title="馋" ><img src="<?php echo TEMPLATE_URL; ?>img/face/6.gif" alt="馋"/></a>
<a href="javascript:grin('[F7]')"  title="闭嘴" ><img src="<?php echo TEMPLATE_URL; ?>img/face/7.gif" alt="闭嘴"/></a>
<a href="javascript:grin('[F8]')"  title="调皮" ><img src="<?php echo TEMPLATE_URL; ?>img/face/8.gif" alt="调皮"/></a>
<a href="javascript:grin('[F9]')"  title="馋" ><img src="<?php echo TEMPLATE_URL; ?>img/face/9.gif" alt="馋"/></a>
<a href="javascript:grin('[F10]')"  title="奸" ><img src="<?php echo TEMPLATE_URL; ?>img/face/10.gif" alt="奸"/></a>
<a href="javascript:grin('[F11]')"  title="怒" ><img src="<?php echo TEMPLATE_URL; ?>img/face/11.gif" alt="怒"/></a>
<a href="javascript:grin('[F12]')"  title="笑" ><img src="<?php echo TEMPLATE_URL; ?>img/face/12.gif" alt="笑" /></a>
<a href="javascript:grin('[F13]')"  title="羞" ><img src="<?php echo TEMPLATE_URL; ?>img/face/13.gif" alt="羞"/></a>
<a href="javascript:grin('[F14]')"  title="汗" ><img src="<?php echo TEMPLATE_URL; ?>img/face/14.gif" alt="汗"/></a>
<a href="javascript:grin('[F15]')"  title="色" ><img src="<?php echo TEMPLATE_URL; ?>img/face/15.gif" alt="色"/></a>
<a href="javascript:grin('[F16]')"  title="萌" ><img src="<?php echo TEMPLATE_URL; ?>img/face/16.gif" alt="萌" /></a>
<a href="javascript:grin('[F17]')"  title="可怜" ><img src="<?php echo TEMPLATE_URL; ?>img/face/17.gif" alt="可怜"/></a>
<a href="javascript:grin('[F18]')"  title="快哭了" ><img src="<?php echo TEMPLATE_URL; ?>img/face/18.gif" alt="快哭了"/></a>
<a href="javascript:grin('[F19]')"  title="呆" ><img src="<?php echo TEMPLATE_URL; ?>img/face/19.gif" alt="呆" /></a>
<a href="javascript:grin('[F20]')"  title="吓" ><img src="<?php echo TEMPLATE_URL; ?>img/face/20.gif" alt="吓"/></a>
<a href="javascript:grin('[F21]')"  title="大笑" ><img src="<?php echo TEMPLATE_URL; ?>img/face/21.gif" alt="大笑"/></a>
