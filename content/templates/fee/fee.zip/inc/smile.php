<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<a href="javascript:grin('[F1]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/1.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F2]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/2.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F3]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/3.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F4]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/4.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F5]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/5.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F6]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/6.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F7]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/7.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F8]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/8.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F9]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/9.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F10]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/10.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F11]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/11.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F12]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/12.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F13]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/13.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F14]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/14.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F15]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/15.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F16]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/16.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F17]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/17.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F18]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/18.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F19]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/19.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F20]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/20.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F21]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/21.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F22]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/22.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F23]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/23.png" class="wp-smiley" alt=""></a>
<a href="javascript:grin('[F24]')"><img src="<?php echo TEMPLATE_URL; ?>static/img/face/24.png" class="wp-smiley" alt=""></a>