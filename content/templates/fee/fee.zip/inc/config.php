<?php
			$Tconfig = 'a:97:{s:4:"logo";s:1:"1";s:7:"bg_open";s:1:"1";s:6:"bg_mbl";s:1:"1";s:7:"regopen";s:1:"1";s:8:"loginpen";s:1:"1";s:4:"qqtz";s:1:"2";s:3:"aos";s:1:"1";s:3:"wow";s:12:"wow fadeInUp";s:5:"moshi";s:1:"2";s:5:"img6g";s:1:"1";s:9:"index_num";s:2:"10";s:9:"pse_title";s:12:"戳你老母";s:5:"fqq_s";s:1:"1";s:6:"fqq_id";s:10:"1444762288";s:4:"more";s:1:"2";s:9:"more_html";s:399:"<li id="menu-item" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-498"><a href="#"><i class="fa fa-flask"></i> 其他工具</a>
<ul class="sub-menu">
	<li id="menu-item" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-3731"><a href="http://api.paniutv.com"><i class="fa fa-windows"></i> VIP解析</a></li>
</ul>
</li>";s:10:"theme_skin";s:6:"45B6F7";s:6:"cms_id";s:7:"3,5,4,9";s:7:"img6_id";s:3:"1,2";s:8:"qq_login";s:1:"2";s:17:"theme_skin_custom";s:0:"";s:8:"qq_appid";s:0:"";s:9:"qq_appkey";s:0:"";s:10:"arr_navico";a:3:{i:1;s:10:"fa fa-home";i:2;s:0:"";i:3;s:0:"";}s:11:"arr_sortico";a:1:{i:1;s:10:"fa fa-plug";}s:12:"focusslide_s";s:1:"2";s:16:"focusslide_src_1";s:48:"https://0d077ef9e74d8.cdn.sohucs.com/rnEg9t5_jpg";s:16:"focusslide_src_2";s:48:"https://0d077ef9e74d8.cdn.sohucs.com/rnEg9t5_jpg";s:16:"focusslide_src_3";s:48:"https://0d077ef9e74d8.cdn.sohucs.com/rnEg9t5_jpg";s:16:"focusslide_src_4";s:48:"https://0d077ef9e74d8.cdn.sohucs.com/rnEg9t5_jpg";s:24:"focusslide_src_zhanshi_1";s:45:"/content/templates/fee/static/img/zhanshi.png";s:24:"focusslide_src_zhanshi_2";s:45:"/content/templates/fee/static/img/zhanshi.png";s:24:"focusslide_src_zhanshi_3";s:45:"/content/templates/fee/static/img/zhanshi.png";s:24:"focusslide_src_zhanshi_4";s:45:"/content/templates/fee/static/img/zhanshi.png";s:18:"focusslide_title_1";s:9:"fee主题";s:18:"focusslide_title_2";s:9:"fee主题";s:18:"focusslide_title_3";s:9:"fee主题";s:18:"focusslide_title_4";s:9:"fee主题";s:19:"focusslide_button_1";s:12:"了解详情";s:19:"focusslide_button_2";s:12:"了解详情";s:19:"focusslide_button_3";s:12:"了解详情";s:19:"focusslide_button_4";s:12:"了解详情";s:17:"focusslide_href_1";s:24:"https://f162.cn/post/343";s:17:"focusslide_href_2";s:24:"https://f162.cn/post/343";s:17:"focusslide_href_3";s:24:"https://f162.cn/post/343";s:17:"focusslide_href_4";s:24:"https://f162.cn/post/343";s:17:"focusslide_text_1";s:91:"响应式布局支持电脑、平板和手机的完美展示<br>
fee主题基于emlog6.0.1";s:17:"focusslide_text_2";s:91:"响应式布局支持电脑、平板和手机的完美展示<br>
fee主题基于emlog6.0.1";s:17:"focusslide_text_3";s:91:"响应式布局支持电脑、平板和手机的完美展示<br>
fee主题基于emlog6.0.1";s:17:"focusslide_text_4";s:91:"响应式布局支持电脑、平板和手机的完美展示<br>
fee主题基于emlog6.0.1";s:11:"left_tags_s";s:1:"1";s:15:"left_tags_style";s:9:"left-tags";s:15:"post_prevnext_s";s:1:"1";s:20:"breadcrumbs_single_s";s:1:"1";s:9:"left_sd_s";s:1:"1";s:5:"weibo";s:16:"https://f162.cn/";s:6:"wechat";s:11:"a1444762288";s:2:"qq";s:10:"1444762288";s:17:"left_qrcode_url_s";s:37:"https://api.17uw.cn/api/qrcode/?text=";s:10:"wechat_img";s:57:"https://f162.cn/content/templates/fee/static/img/wxzf.png";s:11:"side_title1";s:12:"文章归档";s:9:"side_url1";s:14:"/archives.html";s:11:"side_title2";s:9:"留言板";s:9:"side_url2";s:15:"/guestbook.html";s:11:"side_title3";s:12:"友情链接";s:9:"side_url3";s:11:"/links.html";s:11:"side_title4";s:12:"关于我们";s:9:"side_url4";s:11:"/about.html";s:11:"side_title5";s:12:"读者排行";s:9:"side_url5";s:12:"/reader.html";s:11:"side_title6";s:9:"标签云";s:9:"side_url6";s:9:"/tag.html";s:9:"ajaxpager";s:1:"0";s:12:"index_page_s";s:1:"1";s:14:"sideroll_index";s:0:"";s:9:"notices_s";s:1:"0";s:13:"notices_title";s:12:"温馨提示";s:15:"notices_content";s:1224:"现在已经过凌晨了，身体是无价的资本喔，小伙伴早点休息吧！|凌晨1点多了，工作是永远都做不完的，小伙伴别熬坏身子！|亲爱的小伙伴该休息了，身体可是革命的本钱啊！|夜深了，熬夜很容易导致身体内分泌失调，长痘痘的！|四点过了额(⊙o⊙)…，你明天不学习工作吗？？？|你知道吗，此时是国内网络速度最快的时候！|清晨好，这么早就来网站啦，谢谢小伙伴的关注哦，昨晚做的梦好吗？|新的一天又开始了，祝你过得快乐！|小伙伴早上好哦，一天之际在于晨，又是美好的一天！|上午好！今天你看上去好精神哦！|小伙伴啊！该吃午饭啦！有什么好吃的？您有中午休息的好习惯吗？|下午好！外面的天气好吗？记得朵朵白云曾捎来朋友殷殷的祝福。|太阳落山了！快看看夕阳吧！如果外面下雨，就不必了 ^_^ |晚上好，小伙伴今天的心情怎么样？去留言板诉说一下吧！|忙碌了一天，累了吧？去看看最新的新闻资讯醒醒脑吧！|这么晚了，小伙伴还在上网？早点洗洗睡吧，睡前记得洗洗脸喔！明天一天都会萌萌哒！";s:7:"side_mm";s:45:"专注于网络资源搜集共享与发布！";s:8:"side_txt";s:252:"本站从2016年开始至今始终坚持免费搜集分享各种网络资源，现如今本站已发展形成网站源码、主题模板、emlog教程、破解软件、电脑软件、操作系统、经验教程、影视资源等各个领域的资源！";s:6:"tool_s";s:1:"1";s:11:"tool_s_html";s:2436:"<div class="group-detail">
				<ul>
					<li data-card="1" class="card-item">
					<div class="product-brief">
						<i class="fa fa-globe"></i>
						<h4>友情链接</h4>
						<p>
							站长合作互联
						</p>
					</div>
					<div class="product-bottom">
						<ul>
							<li>友链申请</li>
							<li>网址导航</li>
							<li>优站推荐</li>
						</ul>
						<a class="btn btn-primary btn-sm" href="/links">点击进入</a>
					</div>
					</li>
					<li data-card="2" class="card-item">
					<div class="product-brief">
						<i class="fa fa-list"></i>
						<h4>文章归档</h4>
						<p>
							所有文章都搁着
						</p>
					</div>
					<div class="product-bottom">
						<ul>
							<li>今年文章</li>
							<li>去年文章</li>
							<li>好多文章</li>
						</ul>
						<a class="btn btn-primary btn-sm" target="_blank" href="/archives.html">点击进入</a>
					</div>
					</li>
					<li data-card="3" class="card-item active">
					<div class="product-brief">
						<i class="fa fa-file-text-o"></i>
						<h4>留言互动</h4>
						<p>
							不要打广告啊
						</p>
					</div>
					<div class="product-bottom">
						<ul>
							<li>聊天吹水</li>
							<li>投诉建议</li>
							<li>欧泡果奶</li>
						</ul>
						<a class="btn btn-primary btn-sm" target="_blank" href="/guestbook.html">点击进入</a>
					</div>
					</li>
					<li data-card="4" class="card-item">
					<div class="product-brief">
						<i class="fa fa-film"></i>
						<h4>VIP影院</h4>
						<p>
							全网免费影院
						</p>
					</div>
					<div class="product-bottom">
						<ul>
							<li>无收费</li>
							<li>无广告</li>
							<li>全网在线</li>
						</ul>
						<a class="btn btn-primary btn-sm" target="_blank" href="http://paniutv.com">点击进入</a>
					</div>
					</li>
					<li data-card="5" class="card-item">
					<div class="product-brief">
						<i class="fa fa-thumbs-o-up"></i>
						<h4>免费解析</h4>
						<p>
							永久免费VIP解析
						</p>
					</div>
					<div class="product-bottom">
						<ul>
							<li>多条线路</li>
							<li>极速加载</li>
							<li>断点观看</li>
						</ul>
						<a class="btn btn-primary btn-sm" target="_blank" href="http://api.paniutv.com">点击进入</a>
					</div>
					</li>
				</ul>
			</div>";s:7:"gonggao";s:1:"1";s:9:"gonggao_q";s:1:"1";s:11:"index_ad_ad";s:1:"1";s:14:"index_ad_title";s:60:"【原创】emlog模板_fee主题主题介绍与更新记录";s:12:"index_ad_url";s:24:"https://f162.cn/post/343";s:3:"rtc";s:1:"0";s:8:"wintip_m";s:1:"1";s:5:"rtcbt";s:21:"emlog模板_fee主题";s:6:"rtcurl";s:29:"https://f162.cn/post-343.html";s:5:"rtcrd";s:24:"这是广告你吃屎！";s:6:"rtcimg";s:71:"https://cy-pic.kuaizhan.com/g3/5b/15/27d9-7654-4945-b1a7-e98a1609352576";s:5:"rtcan";s:12:"了解一下";s:5:"rtccn";s:94:"全站响应式布局自适应模板,后台模板在线设置，支持博客模式cms模式。";s:6:"img_id";N;s:8:"theme_id";N;}';
		?>