<?php 
  $config = array(
    "cookie" => "SUB=_2A25xsxv0DeRhGeBN7FAW8irMyT2IHXVSyQo8rDV_PUNbm9BeLUvjkW9NRCRXOUpQIOo22ntgGJDaBxA4jajuFG19;",
    "time" => "1555524519",
  );